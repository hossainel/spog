i = input()
while(i):
    if int(i)==42:
        print(i)
        break
    else:
        print(i)
        i = input()
