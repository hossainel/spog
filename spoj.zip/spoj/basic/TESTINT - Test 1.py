i = int(input())
j = int(input())
print(i+j)
