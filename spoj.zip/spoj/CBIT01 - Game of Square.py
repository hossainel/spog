# your code goes here

import math

i = int(input())

for t in range(i):
    s = int(input())
    i = 0
    #print('A: ', s)
    while(s):
        i = i + 1
        tmp = s
        s = tmp - int(math.sqrt(tmp))**2
        #if i % 2: p = 'B: '
        #else: p = 'A: '
        #print(p, tmp, '-', int(math.sqrt(tmp))**2, '=', s)
    if i % 2:
        print('Win')
    else:
        print('Lose')
        
