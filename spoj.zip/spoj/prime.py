# your code goes here

import math

def primeChecker(n):
 if n % 2 == 0: return False
 for i in range(3,math.sqrt(n)+1,2):
  if n % i == 0 :
   return False
  else: pass
 return True

inp = int(input())
for i in range(inp):
 tmp = input().split()
 s = int(tmp[0])
 f = int(tmp[1])
 for j in range(s,f+1):
  if primeChecker(j): print(j)
  else: pass